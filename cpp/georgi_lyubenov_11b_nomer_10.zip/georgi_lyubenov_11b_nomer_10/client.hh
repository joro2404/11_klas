#ifndef CLIENT_HH
#define CLIENT_HH
#include <string>

class Client{

    public:

        std::string name;
        std::string email;
        int id;

};

#endif