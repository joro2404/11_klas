#ifndef BIKE_HH
#define BIKE_HH
#include "machine.hh"
#include <string>

class Bike: public Machine{

    public:

        int cubic_power;

};

#endif