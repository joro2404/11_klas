#ifndef PART_HH
#define PART_HH
#include <string>

class Part{

    public:

        std::string name;
        float price;
        bool forCar;
        bool forBike;

};

#endif