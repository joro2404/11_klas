#ifndef MACHINE_HH
#define MACHINE_HH
#include <string>

class Machine{

    public:

        std::string model;
        int serial_number;

};

#endif