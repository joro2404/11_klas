#include "user.hh"

User::User(int id, std::string name, std::string passowrd){
    this->id = id;
    this->name = name;
    this->password = password;
}