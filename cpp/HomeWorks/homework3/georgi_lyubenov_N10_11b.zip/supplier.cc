#include "supplier.hh"

Supplier::Supplier(std::string name){
    this->name = name;
}
