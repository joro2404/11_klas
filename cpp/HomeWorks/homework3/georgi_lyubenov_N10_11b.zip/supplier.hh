#ifndef SUPPLIER_HH
#define SUPPLIER_HH
#include <string>

class Supplier{

    public:
        std::string name;

        Supplier(std::string name);
};

#endif