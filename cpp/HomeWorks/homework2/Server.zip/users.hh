#ifndef USERS_HH
#define USERS_HH
#include <string>
#include <vector>

namespace users {

    static const std::vector<std::vector<std::string>> names {{"Mario", "dulgo-doamshno"}, {"Gosho", "za 3 dena"}};
}

#endif
