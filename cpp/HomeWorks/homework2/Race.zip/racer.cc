#include "racer.hh"

Racer::Racer(std::string name, int position, int speed){
    this->name = name;
    this->position = position;
    this->speed = speed;
}