#include "media.hh"

media::media(std::string title, std::string author, double price){
    this->title = title;
    this->author = author;
    this->price = price;
}