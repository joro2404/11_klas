#include <iostream>
#include <string>
#include "./food.cpp"
#include "./electronics.cpp"
#include "./others.cpp"
using namespace std;

class Store{
    
    int employee;
    int income;

    public:

        Store(int employee, int income){
            
            this->employee = employee;
            this->income = income;
        }


};