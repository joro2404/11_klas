package org.elsys.glyubenov;

public enum EngineType {
    DIESEL, GASOLINE, ELECTRIC, HYBRID
}
