package main.java.squirrels.com;

public class IncorrectGoingOutForFood extends Exception {
    public IncorrectGoingOutForFood(String errorMessage){
        super(errorMessage);
    }
}
