package main.java.squirrels.com;

public interface IWinter {
    public void passWinter();
}
